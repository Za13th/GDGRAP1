#include <GLFW/glfw3.h>
#include <cmath>
#define PHI 0.161803398874989 //golden ratio x 0.1

int main(void)
{
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(640, 640, "Jayvee Russel A. Torreno", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    /* Make the window's context current */
    glfwMakeContextCurrent(window);

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT);
        glBegin(GL_POLYGON);
        /*assuming a perfect pentagon, in which its topmost vertex will be referred to as A, the two immediately below that are B and C from left to right,
        and the last two at the bottom are D and E, also from left to right*/
        float a=9*PHI/2,//everything is multiplied by 9 to scale it back up 
        b=9*0.0587785252f,//tan36*PHI/2;the origin O is located at the midpoint of B and C and b is the vertical distance from O to A.
        c=9*0.05,//1*0.1/2, based on the ratio of a triangle with the angles of 36, 72, and 72 (Triangle ADE).
        h=9*0.1538841769;//tan72*0.05
        glVertex2f(0.0f, b+.2); //y values are shifted up by 0.2 to help center the pentagon.
        glVertex2f(-a,0.0f+.2);
        glVertex2f(-c,b-h+.2);
        glVertex2f(c, b-h+.2);
        glVertex2f(a, 0.0f+.2);

        glEnd();

        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}